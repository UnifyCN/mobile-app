from pathlib import Path
import subprocess,os,time,json,hashlib
ROOT=Path('/Volumes/Lexar/Dev.noindex/t3-worktrees/Unify/root-companion-second-send-ci/unify-front-end')
OUT=Path('/tmp/unify-companion-359/ci-8df-step-suggestions-r2')
CONTROL="    // Controlled driver check: the second user save cannot finish until released.\n    const savedMessageMock = jest.requireMock('@/services/companion/saveMessage').saveMessage as jest.Mock;\n    const originalSave = savedMessageMock.getMockImplementation()!;\n    let releaseSave!: () => void;\n    let announceSave!: () => void;\n    const heldSave = new Promise<void>(resolve => { releaseSave = resolve; });\n    const saveStarted = new Promise<void>(resolve => { announceSave = resolve; });\n    savedMessageMock.mockImplementation(async (...args: unknown[]) => {\n      const message = args[0] as { role: string; content: string };\n      if (message.role === 'user' && message.content === 'And then?') {\n        announceSave();\n        await heldSave;\n      }\n      return originalSave(...args);\n    });\n    let helperReturned = false;\n    const sending = send('And then?').then(() => { helperReturned = true; });\n    await saveStarted;\n    await new Promise<void>(resolve => setImmediate(resolve));\n    try {\n      console.log('[DEBUG-ci8df-held]', JSON.stringify({ helperReturned,\n        savedSecondQuestion: mockSaved.some(row => row.content === 'And then?'),\n        streamCalls: mockStream.mock.calls.length,\n        draftCount: screen.getAllByTestId('step-draft-card').length }));\n      expect(helperReturned).toBe(false);\n    } finally {\n      releaseSave();\n      await sending;\n    }\n"
TEST=ROOT/'__tests__/companionActions/taskStepSuggestions.test.tsx'
HOOK=ROOT/'hooks/companion/useSendMessage.ts'
fixed=TEST.read_text();hook=HOOK.read_text()
assert hashlib.sha256(fixed.encode()).hexdigest()=='18857be0de7bad6525c88ff762f6b61c2e13ad1eb4f8191321186ce260c781a7'
assert fixed.count('  await fireEventAsync.press(sendButton());')==1
cache=ROOT/'node_modules/.cache/ci-r2';(cache/'tmp').mkdir(parents=True,exist_ok=True)
env=dict(os.environ);env['TMPDIR']=str(cache/'tmp');results=[]
def run(label,expected):
 cmd=['node','node_modules/jest/bin/jest.js','__tests__/companionActions/taskStepSuggestions.test.tsx','--runInBand','--watchAll=false','--testNamePattern=Not now closes','--cacheDirectory='+str(cache/'jest')]
 start=time.monotonic()
 with (OUT/(label+'.log')).open('w') as log:p=subprocess.run(cmd,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
 record={'label':label,'expected_exit':expected,'actual_exit':p.returncode,'command':cmd,'elapsed':time.monotonic()-start}
 (OUT/(label+'.json')).write_text(json.dumps(record,indent=2)+'\n');results.append(record)
 assert p.returncode==expected,record
 return (OUT/(label+'.log')).read_text()
try:
 base=fixed.replace('  fireEventAsync,\n','',1).replace('  await fireEventAsync.press(sendButton());','  fireEvent.press(sendButton());')
 needle="    await send('And then?');\n"
 assert base.count(needle)==fixed.count(needle)==1
 TEST.write_text(base.replace(needle,CONTROL))
 text=run('probe-held-base',1)
 assert 'Expected: false' in text and 'Received: true' in text
 assert '"helperReturned":true' in text and '"savedSecondQuestion":false' in text
 TEST.write_text(fixed.replace(needle,CONTROL))
 text=run('probe-held-fixed',0)
 assert '"helperReturned":false' in text and '"savedSecondQuestion":false' in text
 TEST.write_text(fixed)
 needle='if (suggestedSteps && savedAnswerId !== null) {'
 assert hook.count(needle)==1
 HOOK.write_text(hook.replace(needle,'if (suggestedSteps && savedAnswerId !== null && isNewConversation) {'))
 text=run('probe-second-draft-fault',1)
 assert 'Expected length: 2' in text and 'Received length: 1' in text
finally:
 TEST.write_text(fixed);HOOK.write_text(hook)
 assert TEST.read_text()==fixed and HOOK.read_text()==hook
 (OUT/'probe-restoration.json').write_text(json.dumps({'test_sha256':hashlib.sha256(TEST.read_bytes()).hexdigest(),'hook_sha256':hashlib.sha256(HOOK.read_bytes()).hexdigest(),'restored':True},indent=2)+'\n')
(OUT/'probe-results.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2))
