from pathlib import Path
import subprocess,os,json,time,sys,hashlib
ROOT=Path('/Volumes/Lexar/Dev.noindex/t3-worktrees/Unify/root-companion-second-send-ci/unify-front-end')
OUT=Path('/tmp/unify-companion-359/ci-8df-step-suggestions-r2')
label=sys.argv[1];cmd=sys.argv[2:];cache=ROOT/'node_modules/.cache/ci-r2';(cache/'tmp').mkdir(parents=True,exist_ok=True)
env=dict(os.environ);env['TMPDIR']=str(cache/'tmp');env['npm_config_cache']=str(cache/'npm')
start=time.monotonic()
with (OUT/(label+'.log')).open('w') as log:result=subprocess.run(cmd,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
record={'command':cmd,'cwd':str(ROOT),'exit':result.returncode,'elapsed':time.monotonic()-start,'log_sha256':hashlib.sha256((OUT/(label+'.log')).read_bytes()).hexdigest()}
(OUT/(label+'.json')).write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record));print('\n'.join((OUT/(label+'.log')).read_text().splitlines()[-20:]))
sys.exit(result.returncode)
