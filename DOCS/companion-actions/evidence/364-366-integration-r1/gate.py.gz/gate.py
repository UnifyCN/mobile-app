#!/usr/bin/env python3
# Runs one gate, records command, root, exit, seconds and log path (appends to gates.json).
import json, subprocess, sys, time, os
name, root, log = sys.argv[1], sys.argv[2], sys.argv[3]
cmd = sys.argv[4:]
env = {k: v for k, v in os.environ.items() if not k.startswith('ACTIONS_') or os.environ.get('GATE_KEEP_ACTIONS') == '1'}
t = time.time()
with open(log, 'w') as f:
    p = subprocess.run(cmd, cwd=root, stdout=f, stderr=subprocess.STDOUT, env=env)
rec = {'name': name, 'command': cmd, 'root': root, 'exit': p.returncode, 'seconds': round(time.time() - t, 3), 'natural': True, 'log': log,
       'actions_env': sorted(k for k in env if k.startswith('ACTIONS_'))}
gj = os.path.join(os.path.dirname(log), 'gates.json')
data = json.load(open(gj)) if os.path.exists(gj) else []
data.append(rec); json.dump(data, open(gj, 'w'), indent=1)
print(json.dumps(rec))
