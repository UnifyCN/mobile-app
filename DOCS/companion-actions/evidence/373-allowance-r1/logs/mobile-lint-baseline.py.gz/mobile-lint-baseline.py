import json,subprocess,pathlib,collections
web=pathlib.Path(__file__).resolve().parents[2];mobile=pathlib.Path('/Volumes/Lexar/Dev.noindex/t3-worktrees/Unify/t3-387adb29/unify-front-end');repo=mobile.parent
current=json.loads((web/'tmp/373-allowance-r1/mobile-changed-lint-normal.log').read_text());rows=[];before=[];after=[]
for f in current:
 path=pathlib.Path(f['filePath']);rel=str(path.relative_to(mobile));old=subprocess.run(['git','show','fc33670c0c1f0ac6e2b8a99b9a5a38d96ef04d9f:unify-front-end/'+rel],cwd=repo,text=True,capture_output=True)
 if old.returncode==0:
  result=subprocess.run(['./node_modules/.bin/eslint','--stdin','--stdin-filename',rel,'--format','json'],cwd=mobile,input=old.stdout,text=True,capture_output=True)
  baseline=json.loads(result.stdout)[0]['messages']
 else:baseline=[]
 oldc=collections.Counter((m['severity'],m['ruleId'],m['message']) for m in baseline)
 newc=collections.Counter((m['severity'],m['ruleId'],m['message']) for m in f['messages'])
 rows.append({'file':rel,'baseline_count':sum(oldc.values()),'current_count':sum(newc.values()),'added':list((newc-oldc).elements()),'removed':list((oldc-newc).elements())})
rep={'files':rows,'added_diagnostics':sum(len(x['added']) for x in rows),'removed_diagnostics':sum(len(x['removed']) for x in rows)}
(web/'tmp/373-allowance-r1/mobile-lint-comparison.json').write_text(json.dumps(rep,indent=2)+'\n');print('Mobile lint delta',rep['added_diagnostics'],'added',rep['removed_diagnostics'],'removed')
