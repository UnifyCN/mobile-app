import json,os,pathlib,subprocess,sys
web=pathlib.Path(__file__).resolve().parents[2]
mobile=pathlib.Path('/Volumes/Lexar/Dev.noindex/t3-worktrees/Unify/t3-387adb29/unify-front-end')
mode=sys.argv[1];env={k:v for k,v in os.environ.items() if not k.startswith('ACTIONS_')}
commands={
'mobile-ci':(mobile,['npm','run','test:ci']),
'web-test':(web,['npm','test']),
'web-build':(web,['npm','run','build']),
'mobile-types':(mobile,['npm','run','typecheck']),
'web-types':(web,['./node_modules/.bin/tsc','--noEmit']),
'mobile-i18n':(mobile,['npm','run','check-i18n']),
'web-i18n':(web,['npm','run','check-i18n']),
'web-lint':(web,['./node_modules/.bin/eslint','.','--format','json']),
}
if mode in ['mobile-changed-lint','web-changed-lint']:
 cwd=mobile if mode.startswith('mobile') else web
 repo=mobile.parent if mode.startswith('mobile') else web
 names=subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=repo,text=True).splitlines()
 names+=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=repo,text=True).splitlines()
 if cwd==mobile:names=[n.removeprefix('unify-front-end/') for n in names if n.startswith('unify-front-end/')]
 names=[n for n in names if pathlib.Path(n).suffix in ['.ts','.tsx'] and not n.startswith(('supabase/','tmp/'))]
 if cwd==mobile:names+=['__tests__/companion/allowance.test.ts','__tests__/companionActions/planLocalStack.test.tsx']
 cwd,cmd=cwd,['./node_modules/.bin/eslint',*sorted(set(names)),'--format','json']
else:cwd,cmd=commands[mode]
log=web/'tmp/373-allowance-r1'/f'{mode}-normal.log'
with log.open('w') as f: r=subprocess.run(cmd,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT)
record={'mode':mode,'cwd':str(cwd),'command':cmd,'exit':r.returncode,'inherited_actions_cleared':True}
(web/'tmp/373-allowance-r1'/f'{mode}-command.json').write_text(json.dumps(record,indent=2)+'\n')
print(mode,'exit',r.returncode)
