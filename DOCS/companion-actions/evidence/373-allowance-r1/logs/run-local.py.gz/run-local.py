import os,subprocess,json,pathlib,sys
base=pathlib.Path(__file__).resolve().parents[2]
env=os.environ.copy()
for k in list(env):
 if k.startswith('ACTIONS_'): del env[k]
for line in (base/'tmp/373-allowance-r1/runtime-start-raw.log').read_text().splitlines():
 if line.startswith('export ACTIONS_'):
  k,v=line.removeprefix('export ').split('=',1);env[k]=v.strip('"')
env.update(ACTIONS_DB_CONTAINER='supabase_db_unify-allowance-373-r1',ACTIONS_REST_CONTAINER='supabase_rest_unify-allowance-373-r1',ACTIONS_CONTENT_PORT='3514')
for part in ['db','rest']:
 name=env['ACTIONS_'+part.upper()+'_CONTAINER'];r=json.loads(subprocess.check_output(['docker','inspect',name]))[0];assert r['Config']['Labels']['com.supabase.cli.project']=='unify-allowance-373-r1'
env['ACTIONS_MEASUREMENT_OUTPUT']=str(base/'tmp/373-allowance-r1/local-measurements.json')
env.update(EXPO_PUBLIC_SUPABASE_URL=env['ACTIONS_API_URL'],EXPO_PUBLIC_SUPABASE_ANON_KEY=env['ACTIONS_ANON_KEY'])
mode = sys.argv[1] if len(sys.argv)>1 else 'service'
if mode == 'service':
 cmd=['deno','test','--no-check','--node-modules-dir=none','--allow-net','--allow-env','--allow-read','--allow-run=python3','supabase/tests/companion-actions/allowance_test.ts'];cwd=base
elif mode == 'web':
 cmd=['./node_modules/.bin/vitest','run','components/companion/plans/PlanLocalStack.test.tsx','-t','373 server allowance'];cwd=base
elif mode == 'mobile':
 cmd=['./node_modules/.bin/jest','__tests__/companionActions/planLocalStack.test.tsx','--runInBand','--watchAll=false','--testNamePattern=373 server allowance'];cwd=pathlib.Path('/Volumes/Lexar/Dev.noindex/t3-worktrees/Unify/t3-387adb29/unify-front-end')
elif mode == 'content':
 cmd=['deno','eval','--node-modules-dir=none',"import {startContentStub} from './supabase/tests/companion-actions/support.ts';startContentStub();"];cwd=base
else: raise ValueError(mode)
log=base/('tmp/373-allowance-r1/%s-local-%d.log' % (mode,len(list((base/'tmp/373-allowance-r1').glob(mode+'-local*log')))))
with open(log,'w') as f:r=subprocess.run(cmd,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT)
print(mode,'exit',r.returncode,'log',log.name)
