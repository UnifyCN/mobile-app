from pathlib import Path
import subprocess,os,json,time,hashlib
ROOT=Path('/Volumes/Lexar/Dev.noindex/t3-worktrees/Unify/root-companion-task-edit-ci/unify-front-end')
OUT=Path('/tmp/unify-companion-359/ci-c8b-task-edit-r3')
CONTROL='it(\'a waiting reason change names the reason before and after on the command card, and keeps them after a later edit\', async () => {\n  // Wrong if: the card says only Waiting → Waiting, shows other reasons than the saved\n  // ones, or loses them when the receipt becomes history.\n  // Hold the committed first response until the second interaction has started.\n  // The test controls this order without a sleep or a faster/slower machine.\n  let releaseFirstApply: () => void = () => {};\n  const firstApplyReply = new Promise<void>(resolve => { releaseFirstApply = resolve; });\n  let holdFirstApply = true;\n  let releaseSecondApply!: () => void;\n  let announceSecondApply!: () => void;\n  const secondApplyReply = new Promise<void>(resolve => { releaseSecondApply = resolve; });\n  const secondApplyStarted = new Promise<void>(resolve => { announceSecondApply = resolve; });\n  global.fetch = async (input, init) => {\n    const response = await (server.fetch as unknown as typeof fetch)(input, init);\n    if (\n      holdFirstApply &&\n      typeof init?.body === \'string\' &&\n      JSON.parse(init.body).action === \'apply\'\n    ) {\n      holdFirstApply = false;\n      await firstApplyReply;\n    }\n    if (typeof init?.body === \'string\') {\n      const body = JSON.parse(init.body);\n      if (body.action === \'apply\' && body.operations?.[0]?.waiting_reason === \'Appointment on Monday\') {\n        announceSecondApply();\n        await secondApplyReply;\n      }\n    }\n    return response;\n  };\n  renderScreen();\n  const firstSend = send(`Mark task "${PHONE}" as waiting: Appointment on Friday`);\n  await waitFor(() => expect(writes()).toHaveLength(1));\n  expect(composer().props.editable).toBe(false);\n  // The driver must wait for the real controls before the next user action.\n  let secondHelperReturned = false;\n  const secondSend = send(`Mark task "${PHONE}" as waiting: Appointment on Monday`).then(() => {\n    secondHelperReturned = true;\n  });\n  try {\n    await act(async () => { await Promise.resolve(); });\n  } finally {\n    releaseFirstApply();\n  }\n  await secondApplyStarted;\n  await new Promise<void>(resolve => setImmediate(resolve));\n  try {\n    console.log(\'[DEBUG-ci-edit-held]\', JSON.stringify({ secondHelperReturned,\n      writes: writes().length, cardCount: screen.queryAllByTestId(\'task-command-card\').length,\n      state: server.row(phoneRef), modelCalls: mockStream.mock.calls.length }));\n    expect(secondHelperReturned).toBe(false);\n  } finally {\n    releaseSecondApply();\n    await firstSend;\n    await secondSend;\n  }\n  await waitFor(() => expect(screen.getAllByTestId(\'task-command-card\')).toHaveLength(2));\n  const first = screen.getAllByTestId(\'task-command-card\')[0];\n  const second = screen.getAllByTestId(\'task-command-card\')[1];\n  expect(await within(first).findByText(`${PHONE}: Not started → Waiting`)).toBeTruthy();\n  expect(within(first).getByText(\'Waiting for: (empty) → “Appointment on Friday”\')).toBeTruthy();\n  expect(await within(second).findByText(`${PHONE}: Waiting → Waiting`)).toBeTruthy();\n  expect(\n    within(second).getByText(\'Waiting for: “Appointment on Friday” → “Appointment on Monday”\')\n  ).toBeTruthy();\n  expect(server.row(phoneRef)).toMatchObject({ state: \'waiting\', reason: \'Appointment on Monday\' });\n  // A later edit makes the second receipt history; it keeps its saved reasons.\n  await send(`Rename task "${PHONE}" to "Prepaid plan"`);\n  await screen.findByText(\'Changed in Checklist: Prepaid plan\');\n  expect(await within(second).findByText(/This task changed after this/)).toBeTruthy();\n  expect(\n    within(second).getByText(\'Waiting for: “Appointment on Friday” → “Appointment on Monday”\')\n  ).toBeTruthy();\n  // The private reason text never reaches analytics.\n  expect(mockCapture.mock.calls.length).toBeGreaterThan(0);\n  expect(JSON.stringify(mockCapture.mock.calls)).not.toContain(\'Appointment on\');\n});\n\n'
TEST=ROOT/'__tests__/companionActions/taskEdit.test.tsx'
CARD=ROOT/'components/companion/tasks/TaskActionCards.tsx'
fixed=TEST.read_text();card=CARD.read_text()
assert hashlib.sha256(fixed.encode()).hexdigest()=='d5daa6a40ef9177e6048799ccf100c9e670278e986592a8ae568d2f485132f37'
base=fixed.replace('  fireEventAsync,\n','',1).replace('  await waitFor(() => expect(composer().props.value).toBe(text));\n','',1).replace('  await fireEventAsync.press(sendButton());','  fireEvent.press(sendButton());',1).replace('  const firstSend = send(`Mark task "${PHONE}" as waiting: Appointment on Friday`);','  await send(`Mark task "${PHONE}" as waiting: Appointment on Friday`);',1).replace('  await firstSend;\n','',1)
cache=ROOT/'node_modules/.cache/ci-r3';(cache/'tmp').mkdir(parents=True,exist_ok=True)
env=dict(os.environ);env['TMPDIR']=str(cache/'tmp');results=[]
def held_case(source):
 start=source.index("it('a waiting reason change names");end=source.index('// #365 + #370 composition',start)
 return source[:start]+CONTROL+source[end:]
def run(label,exit_code):
 cmd=['node','node_modules/jest/bin/jest.js','__tests__/companionActions/taskEdit.test.tsx','--runInBand','--watchAll=false','--testNamePattern=a waiting reason change','--cacheDirectory='+str(cache/'jest')]
 start=time.monotonic()
 with (OUT/(label+'.log')).open('w') as log:p=subprocess.run(cmd,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
 record={'label':label,'expected_exit':exit_code,'actual_exit':p.returncode,'command':cmd,'elapsed':time.monotonic()-start}
 (OUT/(label+'.json')).write_text(json.dumps(record,indent=2)+'\n');results.append(record)
 assert p.returncode==exit_code,record
 return (OUT/(label+'.log')).read_text()
try:
 TEST.write_text(held_case(base))
 text=run('probe-held-base',1)
 assert 'Expected: false' in text and 'Received: true' in text and '"secondHelperReturned":true' in text
 TEST.write_text(held_case(fixed))
 text=run('probe-held-fixed',0)
 assert '"secondHelperReturned":false' in text
 TEST.write_text(fixed)
 needle='    detailCommands.find(c => c.messageId === messageId) ??\n    null;\n'
 assert card.count(needle)==1
 CARD.write_text(card.replace(needle,needle+"  if (command && command.receipt.beforeState === command.receipt.afterState) return null;\n",1))
 text=run('probe-same-state-card-fault',1)
 assert 'Expected length: 2' in text and 'Received length: 1' in text
finally:
 TEST.write_text(fixed);CARD.write_text(card)
 assert TEST.read_text()==fixed and CARD.read_text()==card
 (OUT/'probe-restoration.json').write_text(json.dumps({'test_sha256':hashlib.sha256(TEST.read_bytes()).hexdigest(),'card_sha256':hashlib.sha256(CARD.read_bytes()).hexdigest(),'restored':True},indent=2)+'\n')
(OUT/'probe-results.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2))
