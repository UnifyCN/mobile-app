from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import sys

ROOT = Path('/Volumes/Lexar/Dev.noindex/t3-worktrees/Unify/root-companion-step-receipt-ci/unify-front-end')
OUT = Path(__file__).parent
FILES = [ROOT / '__tests__/companionActions/taskStepSuggestions.test.tsx', ROOT / '__tests__/companionActions/taskEdit.test.tsx']
originals = {f: f.read_bytes() for f in FILES}
try:
    for file in FILES:
        text = originals[file].decode()
        test_id = 'step-draft-card' if 'Suggestions' in file.name else 'task-command-card'
        old = "  await waitFor(() => expect(screen.getAllByTestId('" + test_id + "')).toHaveLength(2));"
        trace = """  try {
    await waitFor(() => expect(screen.getAllByTestId('TEST_ID')).toHaveLength(2));
  } catch (error) {
    console.log('REPEATED_SEND_TRACE', JSON.stringify({
      file: 'FILE_NAME',
      saved: mockSaved,
      requests: server.sent.map(body => ({ action: body.action, message_id: body.message_id, source: body.source, conversation_id: body.conversation_id, operations: body.operations })),
      streamCalls: mockStream.mock.calls.map(call => call.slice(0, 2)),
      composer: { value: composer().props.value, editable: composer().props.editable },
      sendDisabled: sendButton().props.disabled,
      queryStates: clients.at(-1)!.getQueryCache().getAll().filter(q => ['conversation-messages', 'companion-conversation-actions'].includes(String(q.queryKey[0]))).map(q => ({ key: q.queryKey, status: q.state.status, fetchStatus: q.state.fetchStatus, data: q.state.data })),
    }));
    throw error;
  }""".replace('TEST_ID', test_id).replace('FILE_NAME', file.name)
        assert text.count(old) == 1, (file, text.count(old))
        file.write_text(text.replace(old, trace))
    attempts = int(sys.argv[1]) if len(sys.argv) > 1 else 3
    full = '--full' in sys.argv
    for attempt in range(1, attempts + 1):
        label = ('full-trace' if full else 'repeated-send-trace') + '-' + str(attempt)
        command = ['node', 'node_modules/jest/bin/jest.js', *(['__tests__'] if full else [str(f.relative_to(ROOT)) for f in FILES]), '--runInBand', '--watchAll=false']
        with (OUT / (label + '.log')).open('w') as log:
            result = subprocess.run(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT, timeout=180)
        (OUT / (label + '.json')).write_text(json.dumps({'command': command, 'exit_code': result.returncode, 'utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}, indent=2) + '\n')
        print(label, result.returncode, flush=True)
        if result.returncode:
            break
finally:
    for file, data in originals.items():
        file.write_bytes(data)
    record = {str(f.relative_to(ROOT)): hashlib.sha256(f.read_bytes()).hexdigest() for f in FILES}
    (OUT / 'trace-restoration.json').write_text(json.dumps(record, indent=2) + '\n')
    print('Original tests restored', flush=True)
