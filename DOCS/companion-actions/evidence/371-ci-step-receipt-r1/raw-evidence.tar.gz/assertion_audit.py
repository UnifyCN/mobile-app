from pathlib import Path
import hashlib
import json
import re
import subprocess

ROOT = Path('/Volumes/Lexar/Dev.noindex/t3-worktrees/Unify/root-companion-step-receipt-ci')
OUT = Path(__file__).parent
FILE = 'unify-front-end/__tests__/companionActions/taskSteps.test.tsx'
BASE = '6b6a302c8b9d17b6831892bd9f211b55f22564cc'
base = subprocess.check_output(['git', 'show', BASE + ':' + FILE], cwd=ROOT)
current = (ROOT / FILE).read_bytes()
guard = b'''  // The receipt can appear before the progress read finishes. Establish the
  // saved checkbox revision before another client changes it.
  await waitFor(() => {
    const current = screen.getByRole('checkbox', { name: 'Prepare the papers' });
    expect(current).toBeChecked();
    expect(current).toBeEnabled();
  });
'''
assert current.count(guard) == 1
assert current.replace(guard, b'') == base
paths = subprocess.check_output(['git', 'diff', BASE, '--name-only', '--', 'unify-front-end'], cwd=ROOT, text=True).splitlines()
assert paths == [FILE]
record = {
    'base': BASE,
    'changed_paths': paths,
    'only_addition_is_precondition': True,
    'all_original_bytes_and_assertions_retained': True,
    'base_sha256': hashlib.sha256(base).hexdigest(),
    'candidate_sha256': hashlib.sha256(current).hexdigest(),
    'base_expect_calls': len(re.findall(rb'\bexpect\(', base)),
    'candidate_expect_calls': len(re.findall(rb'\bexpect\(', current)),
    'product_code_diff': 'empty; only one test driver changed',
    'setup_note': 'An earlier inline audit did not parse because of an extra closing parenthesis. No assertion ran in that failed setup. This file corrects that syntax.',
}
(OUT / 'assertion-audit.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record, indent=2))
