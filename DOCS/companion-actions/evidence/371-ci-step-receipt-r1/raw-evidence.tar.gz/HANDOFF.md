# Mobile CI correction in progress

Status: NOT COMPLETE. Do not integrate or push this private correction yet.

- Root: `/Volumes/Lexar/Dev.noindex/t3-worktrees/Unify/root-companion-step-receipt-ci`.
- Branch: `fix/companion-step-receipt-ci-359`.
- Base HEAD: `6b6a302c8b9d17b6831892bd9f211b55f22564cc`.
- Only tracked change: seven added lines in `unify-front-end/__tests__/companionActions/taskSteps.test.tsx`.
- No product code change. The test change is not committed.

Remote run 41190145739 failed one step receipt assertion at line 694. It expected two historical receipt notices and found one. Lint, translations, and types passed. Native export was skipped. Edge and backend jobs passed. The exact historical cause is not proved by that log.

The private correction waits for the checked checkbox to be enabled after the save, before simulated remote changes. Final domain assertions are unchanged. The whole focused file passes 20 cases. Types and changed-file lint pass; lint retains thirteen earlier warnings.

`probes.py` runs two controlled checks. Holding the progress read proves that the receipt plus one history notice can appear while the checkbox is still unchecked and disabled. It then releases the read and the corrected test passes. Replacing revision equality with value equality causes the same final domain assertion to fail. Both source files were restored exactly. `probe-results.json` records their hashes. This proves the precondition distinction and assertion sensitivity. It does not prove the exact historical CI interleaving.

The full `npm run test:ci` attempt exited 1. The corrected step receipt file passes. Two other files fail: `taskStepSuggestions.test.tsx:534` expects two proposal cards after the second message, and `taskEdit.test.tsx:600` expects two command cards after the second message. The run has 1621 passes, 2 failures, and 31 skips. DST did not run because the main command failed. Preserve this result. Diagnose these failures before another full run. Do not call a passing isolated test a resolution of the full suite.

No owned process remains. The independent dependency clone stays in this root and is ignored. Package and lock files matched the reviewed source before the clone. No native, Docker, hosted, provider, push, PR, or integration action occurred in this private root.

Next: inspect the two remaining failures, test a binding correction without weakening assertions, run the required checks, commit clean evidence and source, and obtain independent review. Native, ticket, and release acceptance remain incomplete.

HANDOFF: COMPANION_PROFILE_371_MOBILE_CI_CORRECTION_IN_PROGRESS
