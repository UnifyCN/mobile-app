from pathlib import Path
import datetime
import hashlib
import json
import subprocess

ROOT = Path('/Volumes/Lexar/Dev.noindex/t3-worktrees/Unify/root-companion-step-receipt-ci/unify-front-end')
OUT = Path(__file__).parent
TEST = ROOT / '__tests__/companionActions/taskSteps.test.tsx'
COMPONENT = ROOT / 'components/companion/tasks/TaskStepsSection.tsx'
NAME = 'a checked-step receipt stays historical when a later client restores the same checkbox value'

def run(label):
    command = ['node', 'node_modules/jest/bin/jest.js', '__tests__/companionActions/taskSteps.test.tsx', '--runInBand', '--watchAll=false', '-t', NAME]
    with (OUT / (label + '.log')).open('w') as log:
        result = subprocess.run(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT, timeout=90)
    record = {'command': command, 'exit_code': result.returncode, 'utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
    (OUT / (label + '.json')).write_text(json.dumps(record, indent=2) + '\n')
    print(label, result.returncode, flush=True)
    return result.returncode

original_test = TEST.read_bytes()
original_component = COMPONENT.read_bytes()
records = []
try:
    text = original_test.decode()
    start = text.index("it('" + NAME)
    end = text.index("it('an unrelated added step", start)
    block = text[start:end]
    gate = '''  let releaseRead!: () => void;
  let signalRead!: () => void;
  const readStarted = new Promise<void>(resolve => { signalRead = resolve; });
  const heldRead = new Promise<void>(resolve => { releaseRead = resolve; });
  const beforeReadGate = global.fetch;
  let holdNextRead = true;
  global.fetch = (async (input, init) => {
    const response = await beforeReadGate(input, init);
    const body = JSON.parse(String(init?.body));
    if (body.action === 'read' && holdNextRead) {
      holdNextRead = false;
      signalRead();
      await heldRead;
    }
    return response;
  }) as typeof fetch;
'''
    block = block.replace('  fireEvent.press(box);', gate + '  fireEvent.press(box);', 1)
    checkpoint = '''  await readStarted;
  await waitFor(() => expect(screen.getAllByText(/This task changed after this/)).toHaveLength(1));
  const beforeProgress = screen.getByRole('checkbox', { name: 'Prepare the papers' });
  expect(beforeProgress).not.toBeChecked();
  expect(beforeProgress).toBeDisabled();
  console.log(JSON.stringify({ control: 'receipt-before-progress', historicalMessages: 1, checkboxChecked: false, checkboxEnabled: false }));
  releaseRead();
'''
    block = block.replace("  await screen.findByText('Checked step: Prepare the papers');\n", "  await screen.findByText('Checked step: Prepare the papers');\n" + checkpoint, 1)
    TEST.write_text(text[:start] + block + text[end:])
    records.append({'label': 'receipt-before-progress-control', 'exit_code': run('receipt-before-progress-control')})
finally:
    TEST.write_bytes(original_test)

try:
    old = 'current?.revision === recorded.afterRevision;'
    new = '(current?.title === recorded.title && current?.done === recorded.done);'
    text = original_component.decode()
    assert text.count(old) == 1
    COMPONENT.write_text(text.replace(old, new))
    records.append({'label': 'historical-revision-fault', 'exit_code': run('historical-revision-fault')})
finally:
    COMPONENT.write_bytes(original_component)

assert TEST.read_bytes() == original_test
assert COMPONENT.read_bytes() == original_component
records.append({'restored_test_sha256': hashlib.sha256(original_test).hexdigest(), 'restored_component_sha256': hashlib.sha256(original_component).hexdigest()})
(OUT / 'probe-results.json').write_text(json.dumps(records, indent=2) + '\n')
print(json.dumps(records, indent=2), flush=True)
